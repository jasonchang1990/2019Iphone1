import UIKit

var myVariable = 50
myVariable = 42
let myConstant = 50
//myConstant = 42
