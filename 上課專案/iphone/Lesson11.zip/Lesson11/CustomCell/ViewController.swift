//
//  ViewController.swift
//  CustomCell
//
//  Created by Robert on 2019/5/16.
//  Copyright © 2019 ML. All rights reserved.
//

import UIKit


class ViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        tableView.delegate = self;
        tableView.dataSource = self;
 */
    }


}

