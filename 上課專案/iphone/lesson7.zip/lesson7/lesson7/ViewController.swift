//
//  ViewController.swift
//  lesson7
//
//  Created by Robert on 2019/4/30.
//  Copyright © 2019 Robert. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.blue;
    }


}

