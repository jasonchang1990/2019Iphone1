//
//  CityCell.swift
//  sqlite
//
//  Created by Robert on 2019/6/27.
//  Copyright © 2019 ios1. All rights reserved.
//

import UIKit

class CityCell: UITableViewCell {
    @IBOutlet var cityImageView:UIImageView!;
    @IBOutlet var countryLabel:UILabel!;
    @IBOutlet var cityLabel:UILabel!;
    @IBOutlet var continentLabel:UILabel!;
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
