//
//  DataSource.swift
//  sqlite
//
//  Created by Robert on 2019/6/18.
//  Copyright © 2019 ios1. All rights reserved.
//

import Foundation
class DataSource{
    
    static var defaults:DataSource = {
        //doSomeThing
        return DataSource();
    }()
}
