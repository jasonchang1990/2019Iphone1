//
//  ViewController.swift
//  FirstApp
//
//  Created by Robert on 2019/6/16.
//  Copyright © 2019 ios1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //0616
        /*
        view.backgroundColor = UIColor.purple
        let myView = UIView(frame: CGRect.zero);
        myView.backgroundColor = UIColor.white;
        //myView.center = view.center;
        view.addSubview(myView);
        
        myView.translatesAutoresizingMaskIntoConstraints = false;
        NSLayoutConstraint.activate([
            myView.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            myView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 30),
            myView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -30),
            myView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -100),
            ]);
 */
        
    }


}

